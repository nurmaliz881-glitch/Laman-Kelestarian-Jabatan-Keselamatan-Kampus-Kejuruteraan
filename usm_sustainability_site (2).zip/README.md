
Laman Kelestarian — Jabatan Keselamatan USM
-----------------------------------------

Pakej ini mengandungi laman statik mudah guna yang boleh dideploy ke mana-mana hosting statik (Netlify, Vercel, GitHub Pages).

Fail penting:
- index.html         : Halaman utama
- styles.css         : Gaya (custom CSS)
- assets/logo-usm.png: Logo placeholder (gantikan dengan logo rasmi anda)
- README.md          : Fail ini

Cara deploy (ringkas):
1. Tukarkan logo placeholder assets/logo-usm.png kepada logo rasmi (nama sama).
2. Muat naik keseluruhan folder ke GitHub dan gunakan GitHub Pages, atau drag-and-drop ke Netlify/Vercel.
3. Untuk fungsi muat naik laporan / borang, sambungkan form ke endpoint backend (contoh: Google Forms, Formspree, atau api anda sendiri).

Jika mahu, saya boleh sediakan versi Next.js / React atau fail ZIP dengan integrasi muat naik (S3 / Google Drive).

-- Sediakan oleh ChatGPT
